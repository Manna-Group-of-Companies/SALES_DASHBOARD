<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:param name="sqlAtom" select="&apos;atom2&apos;"></xsl:param><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="col">
		<xsl:param name="row"></xsl:param>
		<xsl:param name="name"></xsl:param>
		<xsl:value-of select="normalize-space($row/*[local-name()=$name])"></xsl:value-of>
	</xsl:template><xsl:template name="transform">
		<xsl:variable name="rows" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$sqlAtom]//*[local-name()=&apos;Row&apos;]"></xsl:variable>
		<xsl:variable name="h" select="$rows[1]"></xsl:variable>
		<xsl:variable name="margin" select="number(normalize-space($h/*[local-name()=&apos;Margin&apos;]))"></xsl:variable>
		<xsl:variable name="hdrDisc" select="number(concat(&apos;0&apos;, normalize-space($h/*[local-name()=&apos;HeaderDisc&apos;])))"></xsl:variable>
		<xsl:variable name="vendorState" select="normalize-space($h/*[local-name()=&apos;VendorState&apos;])"></xsl:variable>
		<xsl:variable name="tax">
			<xsl:choose>
				<xsl:when test="$vendorState = &apos;&apos;"></xsl:when>
				<xsl:when test="translate($vendorState, &apos;abcdefghijklmnopqrstuvwxyz&apos;, &apos;ABCDEFGHIJKLMNOPQRSTUVWXYZ&apos;) = translate(normalize-space($h/*[local-name()=&apos;HomeState&apos;]), &apos;abcdefghijklmnopqrstuvwxyz&apos;, &apos;ABCDEFGHIJKLMNOPQRSTUVWXYZ&apos;)">
					<xsl:value-of select="normalize-space($h/*[local-name()=&apos;TaxInState&apos;])"></xsl:value-of>
				</xsl:when>
				<xsl:otherwise><xsl:value-of select="normalize-space($h/*[local-name()=&apos;TaxOutState&apos;])"></xsl:value-of></xsl:otherwise>
			</xsl:choose>
		</xsl:variable>

		<!-- Why not, checked in order; the first one wins. Skips (nothing is
		     wrong, there is just nothing to do) start "skip:". -->
		<xsl:variable name="why">
			<xsl:choose>
				<xsl:when test="not($h)">skip: the sales order was not found</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;Enabled&apos;]) != &apos;Y&apos;">skip: @MANNA_IC ENABLED is not Y</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;StartDate&apos;]) = &apos;&apos;">START_DATE is not set in @MANNA_IC</xsl:when>
				<xsl:when test="number(translate($h/*[local-name()=&apos;DocDate&apos;], &apos;-&apos;, &apos;&apos;)) &lt; number(translate(normalize-space($h/*[local-name()=&apos;StartDate&apos;]), &apos;-&apos;, &apos;&apos;))">skip: the sales order is dated before START_DATE</xsl:when>
				<!-- Only orders the sync's PASS M made from ERPNext (user, 4 Nov 2026):
				     NumAtCard is the ERPNext name and the remarks start "From ERPNext"
				     and that name, as New-MfSalesOrderBody writes them. An order keyed in
				     SAP is left to whoever keyed it, even if its reference looks like one. -->
				<xsl:when test="normalize-space($h/*[local-name()=&apos;ErpPrefix&apos;]) = &apos;&apos;">ERP_PREFIX is not set in @MANNA_IC</xsl:when>
				<xsl:when test="not(starts-with(normalize-space($h/*[local-name()=&apos;NumAtCard&apos;]), normalize-space($h/*[local-name()=&apos;ErpPrefix&apos;])))      or not(starts-with(normalize-space($h/*[local-name()=&apos;Remarks&apos;]), concat(&apos;From ERPNext &apos;, normalize-space($h/*[local-name()=&apos;NumAtCard&apos;]))))">skip: not an order from ERPNext - keyed in SAP</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;Cancelled&apos;]) != &apos;N&apos;">skip: the sales order is cancelled</xsl:when>
				<xsl:when test="number($h/*[local-name()=&apos;PoCount&apos;]) &gt; 0">
					<xsl:value-of select="concat(&apos;skip: purchase order &apos;, normalize-space($h/*[local-name()=&apos;PoDocNum&apos;]), &apos; already carries this sales order&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="string($margin) = &apos;NaN&apos; or $margin &lt;= 0">no MARGIN in @MANNA_IC - refusing to buy from Hi-Tech at the customer&apos;s price</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;VendorType&apos;]) != &apos;S&apos;">
					<xsl:value-of select="concat(&apos;supplier &apos;, normalize-space($h/*[local-name()=&apos;Vendor&apos;]), &apos; (VENDOR) is missing or not a supplier&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;VendorFrozen&apos;]) = &apos;Y&apos;">
					<xsl:value-of select="concat(&apos;supplier &apos;, normalize-space($h/*[local-name()=&apos;Vendor&apos;]), &apos; is inactive&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="string($tax) = &apos;&apos;">
					<xsl:value-of select="concat(&apos;no tax code for the supplier state &quot;&apos;, $vendorState, &apos;&quot; (HOME_STATE / TAX_IN_STATE / TAX_OUT_STATE)&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="$rows[normalize-space(*[local-name()=&apos;ItemCode&apos;]) = &apos;&apos;]">a line has no item</xsl:when>
				<xsl:when test="$rows[normalize-space(*[local-name()=&apos;InvntItem&apos;]) != &apos;Y&apos; or normalize-space(*[local-name()=&apos;PrchseItem&apos;]) != &apos;Y&apos; or normalize-space(*[local-name()=&apos;ItemFrozen&apos;]) = &apos;Y&apos;]">
					<xsl:value-of select="concat(normalize-space($rows[normalize-space(*[local-name()=&apos;InvntItem&apos;]) != &apos;Y&apos; or normalize-space(*[local-name()=&apos;PrchseItem&apos;]) != &apos;Y&apos; or normalize-space(*[local-name()=&apos;ItemFrozen&apos;]) = &apos;Y&apos;][1]/*[local-name()=&apos;ItemCode&apos;]), &apos; is not an active stock item Manna Treads can buy&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="$rows[not(number(*[local-name()=&apos;Quantity&apos;]) &gt; 0)]">a line has no quantity</xsl:when>
				<xsl:when test="$rows[not(round(number(*[local-name()=&apos;PriceAfVAT&apos;]) * (1 - $hdrDisc div 100) * 100) div 100 - $margin &gt; 0)]">
					<xsl:value-of select="concat(normalize-space($rows[not(round(number(*[local-name()=&apos;PriceAfVAT&apos;]) * (1 - $hdrDisc div 100) * 100) div 100 - $margin &gt; 0)][1]/*[local-name()=&apos;ItemCode&apos;]), &apos; sells at no more than the margin of &apos;, $margin, &apos;/kg&apos;)"></xsl:value-of>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>

		<Decision>
			<SalesOrder><xsl:value-of select="normalize-space($h/*[local-name()=&apos;DocNum&apos;])"></xsl:value-of></SalesOrder>
			<xsl:choose>
				<xsl:when test="string($why) != &apos;&apos;">
					<Make>N</Make>
					<Reason><xsl:value-of select="$why"></xsl:value-of></Reason>
				</xsl:when>
				<xsl:otherwise>
					<Make>Y</Make>
					<Reason></Reason>
					<xsl:call-template name="bom">
						<xsl:with-param name="rows" select="$rows"></xsl:with-param>
						<xsl:with-param name="h" select="$h"></xsl:with-param>
						<xsl:with-param name="margin" select="$margin"></xsl:with-param>
						<xsl:with-param name="hdrDisc" select="$hdrDisc"></xsl:with-param>
						<xsl:with-param name="tax" select="string($tax)"></xsl:with-param>
					</xsl:call-template>
				</xsl:otherwise>
			</xsl:choose>
		</Decision>
	</xsl:template><xsl:template name="bom">
		<xsl:param name="rows"></xsl:param>
		<xsl:param name="h"></xsl:param>
		<xsl:param name="margin"></xsl:param>
		<xsl:param name="hdrDisc"></xsl:param>
		<xsl:param name="tax"></xsl:param>
		<!-- The ERPNext order's name - only those orders get this far. Copied,
		     because the sync finds the purchase order by it (PASS P adopts by
		     NumAtCard). -->
		<xsl:variable name="erpName" select="normalize-space($h/*[local-name()=&apos;NumAtCard&apos;])"></xsl:variable>
		<BOM>
			<BO>
				<AdmInfo><Object>oPurchaseOrders</Object></AdmInfo>
				<Documents>
					<row>
						<CardCode><xsl:value-of select="normalize-space($h/*[local-name()=&apos;Vendor&apos;])"></xsl:value-of></CardCode>
						<DocDueDate><xsl:value-of select="translate(normalize-space($h/*[local-name()=&apos;DueDate&apos;]), &apos;-&apos;, &apos;&apos;)"></xsl:value-of></DocDueDate>
						<xsl:if test="string($erpName) != &apos;&apos;"><NumAtCard><xsl:value-of select="$erpName"></xsl:value-of></NumAtCard></xsl:if>
						<Comments>
							<xsl:value-of select="concat(&apos;For Manna Treads SO &apos;, normalize-space($h/*[local-name()=&apos;DocNum&apos;]))"></xsl:value-of>
							<xsl:if test="string($erpName) != &apos;&apos;"><xsl:value-of select="concat(&apos; - ERPNext &apos;, $erpName)"></xsl:value-of></xsl:if>
							<xsl:text> - made by B1if</xsl:text>
						</Comments>
						<DiscPrcnt>0</DiscPrcnt>
						<xsl:if test="normalize-space($h/*[local-name()=&apos;PoSeries&apos;]) != &apos;&apos;"><Series><xsl:value-of select="normalize-space($h/*[local-name()=&apos;PoSeries&apos;])"></xsl:value-of></Series></xsl:if>
						<xsl:if test="normalize-space($h/*[local-name()=&apos;PoBranch&apos;]) != &apos;&apos;"><BPLId><xsl:value-of select="normalize-space($h/*[local-name()=&apos;PoBranch&apos;])"></xsl:value-of></BPLId></xsl:if>
						<U_MannaMtSo><xsl:value-of select="normalize-space($h/*[local-name()=&apos;DocEntry&apos;])"></xsl:value-of></U_MannaMtSo>
					</row>
				</Documents>
				<Document_Lines>
					<xsl:for-each select="$rows">
						<xsl:variable name="gross" select="round(number(*[local-name()=&apos;PriceAfVAT&apos;]) * (1 - $hdrDisc div 100) * 100) div 100 - $margin"></xsl:variable>
						<xsl:variable name="vat" select="number(concat(&apos;0&apos;, normalize-space(*[local-name()=&apos;VatPrcnt&apos;])))"></xsl:variable>
						<row>
							<ItemCode><xsl:value-of select="normalize-space(*[local-name()=&apos;ItemCode&apos;])"></xsl:value-of></ItemCode>
							<Quantity><xsl:value-of select="format-number(number(*[local-name()=&apos;Quantity&apos;]), &apos;0.######&apos;)"></xsl:value-of></Quantity>
							<Price><xsl:value-of select="format-number(round(round($gross * 100) div 100 div (1 + $vat div 100) * 1000000) div 1000000, &apos;0.######&apos;)"></xsl:value-of></Price>
							<DiscPrcnt>0</DiscPrcnt>
							<TaxCode><xsl:value-of select="$tax"></xsl:value-of></TaxCode>
							<xsl:if test="normalize-space($h/*[local-name()=&apos;PoWhs&apos;]) != &apos;&apos;"><WhsCode><xsl:value-of select="normalize-space($h/*[local-name()=&apos;PoWhs&apos;])"></xsl:value-of></WhsCode></xsl:if>
							<xsl:if test="normalize-space($h/*[local-name()=&apos;PoLocation&apos;]) != &apos;&apos;"><LocCode><xsl:value-of select="normalize-space($h/*[local-name()=&apos;PoLocation&apos;])"></xsl:value-of></LocCode></xsl:if>
						</row>
					</xsl:for-each>
				</Document_Lines>
			</BO>
		</BOM>
	</xsl:template></xsl:stylesheet>