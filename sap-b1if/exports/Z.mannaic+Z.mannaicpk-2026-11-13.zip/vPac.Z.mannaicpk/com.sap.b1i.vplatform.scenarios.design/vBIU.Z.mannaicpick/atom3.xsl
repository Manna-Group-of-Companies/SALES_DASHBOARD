<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:param name="htAtom" select="&apos;atom2&apos;"></xsl:param><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="quote">
		<xsl:param name="s"></xsl:param>
		<xsl:choose>
			<xsl:when test="contains($s, &quot;&apos;&quot;)">
				<xsl:value-of select="concat(substring-before($s, &quot;&apos;&quot;), &quot;&apos;&apos;&quot;)"></xsl:value-of>
				<xsl:call-template name="quote"><xsl:with-param name="s" select="substring-after($s, &quot;&apos;&quot;)"></xsl:with-param></xsl:call-template>
			</xsl:when>
			<xsl:otherwise><xsl:value-of select="$s"></xsl:value-of></xsl:otherwise>
		</xsl:choose>
	</xsl:template><xsl:template name="transform">
		<xsl:variable name="rows" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$htAtom]//*[local-name()=&apos;Row&apos;][normalize-space(*[local-name()=&apos;Batch&apos;]) = &apos;Y&apos; and normalize-space(*[local-name()=&apos;ItemCode&apos;]) != &apos;&apos;]"></xsl:variable>
		<Sql>
			<Statement>
				<xsl:choose>
					<xsl:when test="not($rows)">SELECT TOP 0 &apos;&apos; AS ItemCode</xsl:when>
					<xsl:otherwise>
SELECT Q.ItemCode, Q.WhsCode, N.DistNumber AS BatchNum, Q.Quantity - ISNULL(Q.CommitQty, 0) AS Avail
FROM OBTQ Q
JOIN OBTN N ON N.AbsEntry = Q.MdAbsEntry AND N.ItemCode = Q.ItemCode
WHERE Q.Quantity - ISNULL(Q.CommitQty, 0) &gt; 0 AND (<xsl:for-each select="$rows"><xsl:if test="position() &gt; 1"> OR </xsl:if>(Q.ItemCode = N&apos;<xsl:call-template name="quote"><xsl:with-param name="s" select="normalize-space(*[local-name()=&apos;ItemCode&apos;])"></xsl:with-param></xsl:call-template>&apos; AND Q.WhsCode = N&apos;<xsl:call-template name="quote"><xsl:with-param name="s" select="normalize-space(*[local-name()=&apos;WhsCode&apos;])"></xsl:with-param></xsl:call-template>&apos;)</xsl:for-each>)
ORDER BY Q.ItemCode, Q.WhsCode, N.InDate, N.AbsEntry
</xsl:otherwise>
				</xsl:choose>
			</Statement>
		</Sql>
	</xsl:template></xsl:stylesheet>