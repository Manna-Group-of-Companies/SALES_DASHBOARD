<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="transform">
		<Sql>
			<Statement>
SELECT
	ISNULL(CAST(P.AbsEntry AS nvarchar(11)), &apos;&apos;) AS PickEntry, ISNULL(P.PickName, &apos;&apos;) AS PickName, ISNULL(P.N, 0) AS Waiting,
	L.PickEntry AS PickLine, L.BaseObject, L.OrderEntry, L.OrderLine,
	CASE WHEN PQ.AnyPicked = 1 THEN L.PickQtty ELSE L.RelQtty END AS Kg,
	ISNULL(O.DocNum, 0) AS SoNum, ISNULL(O.CANCELED, &apos;&apos;) AS SoCancelled, ISNULL(O.CardCode, &apos;&apos;) AS SoCard,
	ISNULL(O.U_MannaMtPo, &apos;&apos;) AS MtPo, ISNULL(O.NumAtCard, &apos;&apos;) AS OrderName,
	ISNULL(R.ItemCode, &apos;&apos;) AS ItemCode, ISNULL(R.LineStatus, &apos;&apos;) AS SoLineStatus, ISNULL(R.WhsCode, &apos;&apos;) AS WhsCode,
	ISNULL(I.ManBtchNum, &apos;N&apos;) AS Batch,
	S.Enabled, S.Customer, S.InvSeries,
	CONVERT(char(10), GETDATE(), 23) AS Today
FROM (
	SELECT
		MAX(CASE WHEN Code = &apos;ENABLED&apos;    THEN U_Value END) AS Enabled,
		MAX(CASE WHEN Code = &apos;CUSTOMER&apos;   THEN U_Value END) AS Customer,
		MAX(CASE WHEN Code = &apos;INV_SERIES&apos; THEN U_Value END) AS InvSeries
	FROM [@MANNA_IC]
) S
LEFT JOIN (
	SELECT W.AbsEntry, W.PickName, W.N
	FROM (
		SELECT K.AbsEntry, X.PickName,
			ROW_NUMBER() OVER (ORDER BY K.AbsEntry) AS Rn, COUNT(*) OVER () AS N
		FROM OPKL K
		CROSS APPLY (
			SELECT CASE WHEN CAST(K.Remarks AS nvarchar(254)) LIKE &apos;ERPNext % - %&apos;
				THEN SUBSTRING(CAST(K.Remarks AS nvarchar(254)), 9, CHARINDEX(&apos; - &apos;, CAST(K.Remarks AS nvarchar(254))) - 9)
				ELSE &apos;&apos; END AS PickName
		) X
		WHERE K.Status &lt;&gt; &apos;C&apos; AND X.PickName &lt;&gt; &apos;&apos; AND ISNULL(K.U_Confirmed, &apos;N&apos;) = &apos;Y&apos;
			AND NOT EXISTS (SELECT 1 FROM OINV V WHERE V.NumAtCard = X.PickName AND V.CANCELED = &apos;N&apos;)
	) W
	WHERE W.Rn = DATEDIFF(MINUTE, &apos;20260101&apos;, GETDATE()) % W.N + 1
) P ON 1 = 1
OUTER APPLY (SELECT CASE WHEN EXISTS (SELECT 1 FROM PKL1 Z WHERE Z.AbsEntry = P.AbsEntry AND Z.PickQtty &gt; 0) THEN 1 ELSE 0 END AS AnyPicked) PQ
LEFT JOIN PKL1 L ON L.AbsEntry = P.AbsEntry AND (PQ.AnyPicked = 0 OR L.PickQtty &gt; 0)
LEFT JOIN ORDR O ON O.DocEntry = L.OrderEntry AND L.BaseObject = 17
LEFT JOIN RDR1 R ON R.DocEntry = L.OrderEntry AND R.LineNum = L.OrderLine AND L.BaseObject = 17
LEFT JOIN OITM I ON I.ItemCode = R.ItemCode
ORDER BY L.PickEntry
</Statement>
		</Sql>
	</xsl:template></xsl:stylesheet>