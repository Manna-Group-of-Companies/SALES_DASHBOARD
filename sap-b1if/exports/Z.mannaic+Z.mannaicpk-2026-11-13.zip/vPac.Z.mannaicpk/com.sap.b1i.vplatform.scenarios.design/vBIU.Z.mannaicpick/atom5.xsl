<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:param name="htAtom" select="&apos;atom2&apos;"></xsl:param><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="quote">
		<xsl:param name="s"></xsl:param>
		<xsl:choose>
			<xsl:when test="contains($s, &quot;&apos;&quot;)">
				<xsl:value-of select="concat(substring-before($s, &quot;&apos;&quot;), &quot;&apos;&apos;&quot;)"></xsl:value-of>
				<xsl:call-template name="quote"><xsl:with-param name="s" select="substring-after($s, &quot;&apos;&quot;)"></xsl:with-param></xsl:call-template>
			</xsl:when>
			<xsl:otherwise><xsl:value-of select="$s"></xsl:value-of></xsl:otherwise>
		</xsl:choose>
	</xsl:template><xsl:template name="transform">
		<xsl:variable name="h" select="(/vpf:Msg/vpf:Body/vpf:Payload[@id=$htAtom]//*[local-name()=&apos;Row&apos;])[1]"></xsl:variable>
		<xsl:variable name="po" select="number(normalize-space($h/*[local-name()=&apos;MtPo&apos;]))"></xsl:variable>
		<xsl:variable name="name">
			<xsl:call-template name="quote"><xsl:with-param name="s" select="normalize-space($h/*[local-name()=&apos;PickName&apos;])"></xsl:with-param></xsl:call-template>
		</xsl:variable>
		<Sql>
			<Statement>
				<xsl:choose>
					<!-- No pick list this run (step 3 is timer-triggered), or Hi-Tech's
					     order names no purchase order: the settings alone, because the
					     decision's B1 Object atoms read Manna Treads' vendor by them. -->
					<xsl:when test="string($po) = &apos;NaN&apos; or $po != floor($po) or $po &lt; 1">
SELECT &apos;&apos; AS Kind, S.*, 0 AS GrpoCount, 0 AS DnCount
FROM (
	SELECT
		MAX(CASE WHEN Code = &apos;ENABLED&apos;     THEN U_Value END) AS Enabled,
		MAX(CASE WHEN Code = &apos;VENDOR&apos;      THEN U_Value END) AS Vendor,
		MAX(CASE WHEN Code = &apos;PO_BRANCH&apos;   THEN U_Value END) AS Branch,
		MAX(CASE WHEN Code = &apos;GRPO_SERIES&apos; THEN U_Value END) AS GrpoSeries,
		MAX(CASE WHEN Code = &apos;DN_SERIES&apos;   THEN U_Value END) AS DnSeries
	FROM [@MANNA_IC]
) S
</xsl:when>
					<xsl:otherwise>
SELECT D.*, S.*,
	(SELECT COUNT(*) FROM OPDN G WHERE G.NumAtCard = N&apos;<xsl:value-of select="$name"></xsl:value-of>&apos; AND G.CANCELED = &apos;N&apos; AND N&apos;<xsl:value-of select="$name"></xsl:value-of>&apos; &lt;&gt; &apos;&apos;) AS GrpoCount,
	(SELECT COUNT(*) FROM ODLN G WHERE G.NumAtCard = N&apos;<xsl:value-of select="$name"></xsl:value-of>&apos; AND G.CANCELED = &apos;N&apos; AND N&apos;<xsl:value-of select="$name"></xsl:value-of>&apos; &lt;&gt; &apos;&apos;) AS DnCount
FROM (
	SELECT &apos;PO&apos; AS Kind, P.DocEntry, P.DocNum, P.CardCode, P.CANCELED AS Cancelled, ISNULL(P.U_MannaMtSo, &apos;&apos;) AS MtSo,
		L.LineNum, ISNULL(L.ItemCode, &apos;&apos;) AS ItemCode, L.LineStatus
	FROM OPOR P JOIN POR1 L ON L.DocEntry = P.DocEntry
	WHERE P.DocEntry = <xsl:value-of select="format-number($po, &apos;0&apos;)"></xsl:value-of>
	UNION ALL
	SELECT &apos;SO&apos;, O.DocEntry, O.DocNum, O.CardCode, O.CANCELED, &apos;&apos;, L.LineNum, ISNULL(L.ItemCode, &apos;&apos;), L.LineStatus
	FROM ORDR O JOIN RDR1 L ON L.DocEntry = O.DocEntry
	WHERE CAST(O.DocEntry AS nvarchar(11)) = (SELECT ISNULL(U_MannaMtSo, &apos;&apos;) FROM OPOR WHERE DocEntry = <xsl:value-of select="format-number($po, &apos;0&apos;)"></xsl:value-of>)
) D
CROSS JOIN (
	SELECT
		MAX(CASE WHEN Code = &apos;ENABLED&apos;     THEN U_Value END) AS Enabled,
		MAX(CASE WHEN Code = &apos;VENDOR&apos;      THEN U_Value END) AS Vendor,
		MAX(CASE WHEN Code = &apos;PO_BRANCH&apos;   THEN U_Value END) AS Branch,
		MAX(CASE WHEN Code = &apos;GRPO_SERIES&apos; THEN U_Value END) AS GrpoSeries,
		MAX(CASE WHEN Code = &apos;DN_SERIES&apos;   THEN U_Value END) AS DnSeries
	FROM [@MANNA_IC]
) S
ORDER BY D.Kind, D.LineNum
</xsl:otherwise>
				</xsl:choose>
			</Statement>
		</Sql>
	</xsl:template></xsl:stylesheet>