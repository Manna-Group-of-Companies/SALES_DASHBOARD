<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:param name="htAtom" select="&apos;atom2&apos;"></xsl:param><xsl:param name="batchAtom" select="&apos;atom4&apos;"></xsl:param><xsl:param name="mtAtom" select="&apos;atom6&apos;"></xsl:param><xsl:variable name="lc" select="&apos;abcdefghijklmnopqrstuvwxyz&apos;"></xsl:variable><xsl:variable name="uc" select="&apos;ABCDEFGHIJKLMNOPQRSTUVWXYZ&apos;"></xsl:variable><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="transform">
		<xsl:variable name="pk" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$htAtom]//*[local-name()=&apos;Row&apos;]"></xsl:variable>
		<xsl:variable name="bt" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$batchAtom]//*[local-name()=&apos;Row&apos;]"></xsl:variable>
		<xsl:variable name="mt" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$mtAtom]//*[local-name()=&apos;Row&apos;]"></xsl:variable>
		<xsl:variable name="h" select="$pk[1]"></xsl:variable>
		<xsl:variable name="m" select="$mt[1]"></xsl:variable>
		<xsl:variable name="poRows" select="$mt[normalize-space(*[local-name()=&apos;Kind&apos;]) = &apos;PO&apos;]"></xsl:variable>
		<xsl:variable name="soRows" select="$mt[normalize-space(*[local-name()=&apos;Kind&apos;]) = &apos;SO&apos;]"></xsl:variable>
		<xsl:variable name="name" select="normalize-space($h/*[local-name()=&apos;PickName&apos;])"></xsl:variable>

		<!-- The first line whose item Manna Treads' purchase order or sales order
		     has no open line for, and the first batch item Hi-Tech holds too
		     little of. -->
		<xsl:variable name="noPo">
			<xsl:for-each select="$pk">
				<xsl:variable name="it" select="translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc)"></xsl:variable>
				<xsl:if test="not($poRows[translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc) = $it and normalize-space(*[local-name()=&apos;LineStatus&apos;]) = &apos;O&apos;])"><xsl:value-of select="concat(normalize-space(*[local-name()=&apos;ItemCode&apos;]), &apos; &apos;)"></xsl:value-of></xsl:if>
			</xsl:for-each>
		</xsl:variable>
		<xsl:variable name="noSo">
			<xsl:for-each select="$pk">
				<xsl:variable name="it" select="translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc)"></xsl:variable>
				<xsl:if test="not($soRows[translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc) = $it and normalize-space(*[local-name()=&apos;LineStatus&apos;]) = &apos;O&apos;])"><xsl:value-of select="concat(normalize-space(*[local-name()=&apos;ItemCode&apos;]), &apos; &apos;)"></xsl:value-of></xsl:if>
			</xsl:for-each>
		</xsl:variable>
		<xsl:variable name="shortBatch">
			<xsl:for-each select="$pk[normalize-space(*[local-name()=&apos;Batch&apos;]) = &apos;Y&apos;]">
				<xsl:variable name="it" select="normalize-space(*[local-name()=&apos;ItemCode&apos;])"></xsl:variable>
				<xsl:variable name="wh" select="normalize-space(*[local-name()=&apos;WhsCode&apos;])"></xsl:variable>
				<xsl:variable name="have" select="sum($bt[normalize-space(*[local-name()=&apos;ItemCode&apos;]) = $it and normalize-space(*[local-name()=&apos;WhsCode&apos;]) = $wh]/*[local-name()=&apos;Avail&apos;])"></xsl:variable>
				<xsl:if test="$have + 0.0005 &lt; number(*[local-name()=&apos;Kg&apos;])"><xsl:value-of select="concat($it, &apos; (&apos;, format-number($have, &apos;0.###&apos;), &apos; kg in batches in &apos;, $wh, &apos;) &apos;)"></xsl:value-of></xsl:if>
			</xsl:for-each>
		</xsl:variable>

		<xsl:variable name="why">
			<xsl:choose>
				<xsl:when test="not($h)">Hi-Tech&apos;s query returned nothing</xsl:when>
				<!-- Step 3 runs on a timer; most runs find nothing to do. -->
				<xsl:when test="normalize-space($h/*[local-name()=&apos;PickEntry&apos;]) = &apos;&apos;">skip: no ERPNext pick list waiting in Hi-Tech</xsl:when>
				<xsl:when test="$name = &apos;&apos;">skip: not from ERPNext (its Remarks do not start &quot;ERPNext PICK-...&quot;)</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;Enabled&apos;]) != &apos;Y&apos;">skip: Hi-Tech&apos;s @MANNA_IC ENABLED is not Y</xsl:when>
				<xsl:when test="$pk[normalize-space(*[local-name()=&apos;BaseObject&apos;]) != &apos;17&apos;]">a pick list line is not on a sales order</xsl:when>
				<xsl:when test="$pk[normalize-space(*[local-name()=&apos;OrderEntry&apos;]) != normalize-space($h/*[local-name()=&apos;OrderEntry&apos;])]">the pick list spans more than one sales order</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;SoCancelled&apos;]) != &apos;N&apos;">Hi-Tech&apos;s sales order is cancelled or missing</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;MtPo&apos;]) = &apos;&apos;">skip: Hi-Tech&apos;s sales order was not made by B1if (U_MannaMtPo is empty)</xsl:when>
				<xsl:when test="$pk[normalize-space(*[local-name()=&apos;SoLineStatus&apos;]) != &apos;O&apos;]">
					<xsl:value-of select="concat(normalize-space($pk[normalize-space(*[local-name()=&apos;SoLineStatus&apos;]) != &apos;O&apos;][1]/*[local-name()=&apos;ItemCode&apos;]), &apos; is closed on Hi-Tech sales order &apos;, normalize-space($h/*[local-name()=&apos;SoNum&apos;]))"></xsl:value-of>
				</xsl:when>
				<xsl:when test="$pk[not(number(*[local-name()=&apos;Kg&apos;]) &gt; 0)]">a pick list line has no kilos</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;Customer&apos;]) = &apos;&apos;">Hi-Tech&apos;s @MANNA_IC has no CUSTOMER</xsl:when>
				<xsl:when test="string($shortBatch) != &apos;&apos;">
					<xsl:value-of select="concat(&apos;not enough in batches: &apos;, normalize-space($shortBatch))"></xsl:value-of>
				</xsl:when>
				<xsl:when test="not($m)">Manna Treads&apos; query returned nothing</xsl:when>
				<xsl:when test="not($poRows)">
					<xsl:value-of select="concat(&apos;Manna Treads purchase order (DocEntry &apos;, normalize-space($h/*[local-name()=&apos;MtPo&apos;]), &apos;) was not found&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="normalize-space($m/*[local-name()=&apos;Enabled&apos;]) != &apos;Y&apos;">skip: Manna Treads&apos; @MANNA_IC ENABLED is not Y</xsl:when>
				<xsl:when test="number($m/*[local-name()=&apos;GrpoCount&apos;]) &gt; 0 or number($m/*[local-name()=&apos;DnCount&apos;]) &gt; 0">
					<xsl:value-of select="concat(&apos;skip: Manna Treads already has a goods receipt or delivery carrying &apos;, $name)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="normalize-space($poRows[1]/*[local-name()=&apos;Cancelled&apos;]) != &apos;N&apos;">Manna Treads&apos; purchase order is cancelled</xsl:when>
				<xsl:when test="not($soRows)">Manna Treads&apos; sales order for the purchase order was not found</xsl:when>
				<xsl:when test="normalize-space($soRows[1]/*[local-name()=&apos;Cancelled&apos;]) != &apos;N&apos;">Manna Treads&apos; sales order is cancelled</xsl:when>
				<xsl:when test="string($noPo) != &apos;&apos;">
					<xsl:value-of select="concat(&apos;not open on Manna Treads purchase order &apos;, normalize-space($poRows[1]/*[local-name()=&apos;DocNum&apos;]), &apos;: &apos;, normalize-space($noPo))"></xsl:value-of>
				</xsl:when>
				<xsl:when test="string($noSo) != &apos;&apos;">
					<xsl:value-of select="concat(&apos;not open on Manna Treads sales order &apos;, normalize-space($soRows[1]/*[local-name()=&apos;DocNum&apos;]), &apos;: &apos;, normalize-space($noSo))"></xsl:value-of>
				</xsl:when>
				<xsl:when test="normalize-space($m/*[local-name()=&apos;DnSeries&apos;]) = &apos;&apos;">Manna Treads&apos; @MANNA_IC has no DN_SERIES - it has no delivery series of its own (5 Nov 2026)</xsl:when>
				<xsl:when test="normalize-space($m/*[local-name()=&apos;Vendor&apos;]) = &apos;&apos;">Manna Treads&apos; @MANNA_IC has no VENDOR</xsl:when>
			</xsl:choose>
		</xsl:variable>

		<xsl:variable name="today" select="translate(normalize-space($h/*[local-name()=&apos;Today&apos;]), &apos;-&apos;, &apos;&apos;)"></xsl:variable>
		<xsl:variable name="comment" select="concat(&apos;Pick list &apos;, $name, &apos; (Hi-Tech pick list &apos;, normalize-space($h/*[local-name()=&apos;PickEntry&apos;]), &apos;) - made by B1if&apos;)"></xsl:variable>

		<Decision>
			<PickList><xsl:value-of select="normalize-space($h/*[local-name()=&apos;PickEntry&apos;])"></xsl:value-of></PickList>
			<PickName><xsl:value-of select="$name"></xsl:value-of></PickName>
			<xsl:choose>
				<xsl:when test="string($why) != &apos;&apos;">
					<Make>N</Make>
					<Reason><xsl:value-of select="$why"></xsl:value-of></Reason>
					<!-- Reads only: Hi-Tech's customer record for Manna Treads, and
					     Manna Treads' vendor record for Hi-Tech, by the settings. -->
					<Inv>
						<CallMethod>Synchronous Retrieval</CallMethod>
						<CallObject>2</CallObject>
						<CallKeyName>CardCode</CallKeyName>
						<CallKey><xsl:value-of select="normalize-space($h/*[local-name()=&apos;Customer&apos;])"></xsl:value-of></CallKey>
					</Inv>
					<Grpo>
						<CallMethod>Synchronous Retrieval</CallMethod>
						<CallObject>2</CallObject>
						<CallKeyName>CardCode</CallKeyName>
						<CallKey><xsl:value-of select="normalize-space($m/*[local-name()=&apos;Vendor&apos;])"></xsl:value-of></CallKey>
					</Grpo>
					<Dn>
						<CallMethod>Synchronous Retrieval</CallMethod>
						<CallObject>2</CallObject>
						<CallKeyName>CardCode</CallKeyName>
						<CallKey><xsl:value-of select="normalize-space($m/*[local-name()=&apos;Vendor&apos;])"></xsl:value-of></CallKey>
					</Dn>
				</xsl:when>
				<xsl:otherwise>
					<Make>Y</Make>
					<Reason></Reason>
					<Inv>
						<CallMethod>Synchronous Insert</CallMethod>
						<CallObject>13</CallObject>
						<CallKeyName>DocEntry</CallKeyName>
						<CallKey></CallKey>
						<BOM>
							<BO>
								<AdmInfo><Object>13</Object><Version>2</Version></AdmInfo>
								<Documents>
									<row>
										<CardCode><xsl:value-of select="normalize-space($h/*[local-name()=&apos;SoCard&apos;])"></xsl:value-of></CardCode>
										<DocDate><xsl:value-of select="$today"></xsl:value-of></DocDate>
										<DocDueDate><xsl:value-of select="$today"></xsl:value-of></DocDueDate>
										<NumAtCard><xsl:value-of select="$name"></xsl:value-of></NumAtCard>
										<Comments><xsl:value-of select="$comment"></xsl:value-of></Comments>
										<xsl:if test="normalize-space($h/*[local-name()=&apos;InvSeries&apos;]) != &apos;&apos;"><Series><xsl:value-of select="normalize-space($h/*[local-name()=&apos;InvSeries&apos;])"></xsl:value-of></Series></xsl:if>
									</row>
								</Documents>
								<Document_Lines>
									<xsl:for-each select="$pk">
										<row>
											<BaseType>17</BaseType>
											<BaseEntry><xsl:value-of select="normalize-space(*[local-name()=&apos;OrderEntry&apos;])"></xsl:value-of></BaseEntry>
											<BaseLine><xsl:value-of select="normalize-space(*[local-name()=&apos;OrderLine&apos;])"></xsl:value-of></BaseLine>
											<Quantity><xsl:value-of select="format-number(number(*[local-name()=&apos;Kg&apos;]), &apos;0.###&apos;)"></xsl:value-of></Quantity>
										</row>
									</xsl:for-each>
								</Document_Lines>
								<xsl:if test="$pk[normalize-space(*[local-name()=&apos;Batch&apos;]) = &apos;Y&apos;]">
									<BatchNumbers>
										<xsl:for-each select="$pk">
											<xsl:if test="normalize-space(*[local-name()=&apos;Batch&apos;]) = &apos;Y&apos;">
												<xsl:variable name="it" select="normalize-space(*[local-name()=&apos;ItemCode&apos;])"></xsl:variable>
												<xsl:variable name="wh" select="normalize-space(*[local-name()=&apos;WhsCode&apos;])"></xsl:variable>
												<xsl:call-template name="fifo">
													<xsl:with-param name="batches" select="$bt[normalize-space(*[local-name()=&apos;ItemCode&apos;]) = $it and normalize-space(*[local-name()=&apos;WhsCode&apos;]) = $wh]"></xsl:with-param>
													<xsl:with-param name="need" select="round(number(*[local-name()=&apos;Kg&apos;]) * 1000) div 1000"></xsl:with-param>
													<xsl:with-param name="line" select="position() - 1"></xsl:with-param>
												</xsl:call-template>
											</xsl:if>
										</xsl:for-each>
									</BatchNumbers>
								</xsl:if>
							</BO>
						</BOM>
					</Inv>
					<Grpo>
						<CallMethod>Synchronous Insert</CallMethod>
						<CallObject>20</CallObject>
						<CallKeyName>DocEntry</CallKeyName>
						<CallKey></CallKey>
						<BOM>
							<BO>
								<AdmInfo><Object>20</Object><Version>2</Version></AdmInfo>
								<Documents>
									<row>
										<CardCode><xsl:value-of select="normalize-space($poRows[1]/*[local-name()=&apos;CardCode&apos;])"></xsl:value-of></CardCode>
										<DocDate><xsl:value-of select="$today"></xsl:value-of></DocDate>
										<DocDueDate><xsl:value-of select="$today"></xsl:value-of></DocDueDate>
										<NumAtCard><xsl:value-of select="$name"></xsl:value-of></NumAtCard>
										<Comments><xsl:value-of select="$comment"></xsl:value-of></Comments>
										<xsl:if test="normalize-space($m/*[local-name()=&apos;GrpoSeries&apos;]) != &apos;&apos;"><Series><xsl:value-of select="normalize-space($m/*[local-name()=&apos;GrpoSeries&apos;])"></xsl:value-of></Series></xsl:if>
										<xsl:if test="normalize-space($m/*[local-name()=&apos;Branch&apos;]) != &apos;&apos;"><BPL_IDAssignedToInvoice><xsl:value-of select="normalize-space($m/*[local-name()=&apos;Branch&apos;])"></xsl:value-of></BPL_IDAssignedToInvoice></xsl:if>
									</row>
								</Documents>
								<Document_Lines>
									<xsl:for-each select="$pk">
										<xsl:variable name="it" select="translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc)"></xsl:variable>
										<xsl:variable name="pl" select="$poRows[translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc) = $it and normalize-space(*[local-name()=&apos;LineStatus&apos;]) = &apos;O&apos;][1]"></xsl:variable>
										<row>
											<BaseType>22</BaseType>
											<BaseEntry><xsl:value-of select="normalize-space($pl/*[local-name()=&apos;DocEntry&apos;])"></xsl:value-of></BaseEntry>
											<BaseLine><xsl:value-of select="normalize-space($pl/*[local-name()=&apos;LineNum&apos;])"></xsl:value-of></BaseLine>
											<Quantity><xsl:value-of select="format-number(number(*[local-name()=&apos;Kg&apos;]), &apos;0.###&apos;)"></xsl:value-of></Quantity>
										</row>
									</xsl:for-each>
								</Document_Lines>
							</BO>
						</BOM>
					</Grpo>
					<Dn>
						<CallMethod>Synchronous Insert</CallMethod>
						<CallObject>15</CallObject>
						<CallKeyName>DocEntry</CallKeyName>
						<CallKey></CallKey>
						<BOM>
							<BO>
								<AdmInfo><Object>15</Object><Version>2</Version></AdmInfo>
								<Documents>
									<row>
										<CardCode><xsl:value-of select="normalize-space($soRows[1]/*[local-name()=&apos;CardCode&apos;])"></xsl:value-of></CardCode>
										<DocDate><xsl:value-of select="$today"></xsl:value-of></DocDate>
										<DocDueDate><xsl:value-of select="$today"></xsl:value-of></DocDueDate>
										<NumAtCard><xsl:value-of select="$name"></xsl:value-of></NumAtCard>
										<Comments><xsl:value-of select="$comment"></xsl:value-of></Comments>
										<Series><xsl:value-of select="normalize-space($m/*[local-name()=&apos;DnSeries&apos;])"></xsl:value-of></Series>
										<xsl:if test="normalize-space($m/*[local-name()=&apos;Branch&apos;]) != &apos;&apos;"><BPL_IDAssignedToInvoice><xsl:value-of select="normalize-space($m/*[local-name()=&apos;Branch&apos;])"></xsl:value-of></BPL_IDAssignedToInvoice></xsl:if>
									</row>
								</Documents>
								<Document_Lines>
									<xsl:for-each select="$pk">
										<xsl:variable name="it" select="translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc)"></xsl:variable>
										<xsl:variable name="sl" select="$soRows[translate(normalize-space(*[local-name()=&apos;ItemCode&apos;]), $lc, $uc) = $it and normalize-space(*[local-name()=&apos;LineStatus&apos;]) = &apos;O&apos;][1]"></xsl:variable>
										<row>
											<BaseType>17</BaseType>
											<BaseEntry><xsl:value-of select="normalize-space($sl/*[local-name()=&apos;DocEntry&apos;])"></xsl:value-of></BaseEntry>
											<BaseLine><xsl:value-of select="normalize-space($sl/*[local-name()=&apos;LineNum&apos;])"></xsl:value-of></BaseLine>
											<Quantity><xsl:value-of select="format-number(number(*[local-name()=&apos;Kg&apos;]), &apos;0.###&apos;)"></xsl:value-of></Quantity>
										</row>
									</xsl:for-each>
								</Document_Lines>
							</BO>
						</BOM>
					</Dn>
				</xsl:otherwise>
			</xsl:choose>
		</Decision>
	</xsl:template><xsl:template name="fifo">
		<xsl:param name="batches"></xsl:param>
		<xsl:param name="need"></xsl:param>
		<xsl:param name="line"></xsl:param>
		<xsl:if test="$need &gt; 0.0005 and $batches">
			<xsl:variable name="avail" select="round(number($batches[1]/*[local-name()=&apos;Avail&apos;]) * 1000) div 1000"></xsl:variable>
			<xsl:variable name="take">
				<xsl:choose>
					<xsl:when test="$avail &lt; $need"><xsl:value-of select="$avail"></xsl:value-of></xsl:when>
					<xsl:otherwise><xsl:value-of select="$need"></xsl:value-of></xsl:otherwise>
				</xsl:choose>
			</xsl:variable>
			<xsl:if test="number($take) &gt; 0">
				<row>
					<BatchNumber><xsl:value-of select="normalize-space($batches[1]/*[local-name()=&apos;BatchNum&apos;])"></xsl:value-of></BatchNumber>
					<Quantity><xsl:value-of select="format-number(number($take), &apos;0.###&apos;)"></xsl:value-of></Quantity>
					<BaseLineNumber><xsl:value-of select="$line"></xsl:value-of></BaseLineNumber>
				</row>
			</xsl:if>
			<xsl:call-template name="fifo">
				<xsl:with-param name="batches" select="$batches[position() &gt; 1]"></xsl:with-param>
				<xsl:with-param name="need" select="round(($need - number($take)) * 1000) div 1000"></xsl:with-param>
				<xsl:with-param name="line" select="$line"></xsl:with-param>
			</xsl:call-template>
		</xsl:if>
	</xsl:template></xsl:stylesheet>