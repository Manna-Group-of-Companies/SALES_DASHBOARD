<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:param name="mtAtom" select="&apos;atom8&apos;"></xsl:param><xsl:param name="htAtom" select="&apos;atom10&apos;"></xsl:param><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="transform">
		<xsl:variable name="po" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$mtAtom]//*[local-name()=&apos;Row&apos;]"></xsl:variable>
		<xsl:variable name="ht" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$htAtom]//*[local-name()=&apos;Row&apos;]"></xsl:variable>
		<xsl:variable name="h" select="$po[1]"></xsl:variable>
		<xsl:variable name="s" select="$ht[1]"></xsl:variable>
		<xsl:variable name="custState" select="normalize-space($s/*[local-name()=&apos;CustomerState&apos;])"></xsl:variable>
		<xsl:variable name="tax">
			<xsl:choose>
				<xsl:when test="$custState = &apos;&apos;"></xsl:when>
				<xsl:when test="translate($custState, &apos;abcdefghijklmnopqrstuvwxyz&apos;, &apos;ABCDEFGHIJKLMNOPQRSTUVWXYZ&apos;) = translate(normalize-space($s/*[local-name()=&apos;HomeState&apos;]), &apos;abcdefghijklmnopqrstuvwxyz&apos;, &apos;ABCDEFGHIJKLMNOPQRSTUVWXYZ&apos;)">
					<xsl:value-of select="normalize-space($s/*[local-name()=&apos;TaxInState&apos;])"></xsl:value-of>
				</xsl:when>
				<xsl:otherwise><xsl:value-of select="normalize-space($s/*[local-name()=&apos;TaxOutState&apos;])"></xsl:value-of></xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="badItem" select="$ht[normalize-space(*[local-name()=&apos;SellItem&apos;]) != &apos;Y&apos; or normalize-space(*[local-name()=&apos;InvntItem&apos;]) != &apos;Y&apos; or normalize-space(*[local-name()=&apos;ItemFrozen&apos;]) = &apos;Y&apos;][1]"></xsl:variable>

		<xsl:variable name="why">
			<xsl:choose>
				<xsl:when test="not($h)">skip: the purchase order was not found</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;MtSo&apos;]) = &apos;&apos;">skip: not made by B1if from a sales order (U_MannaMtSo is empty)</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;Cancelled&apos;]) != &apos;N&apos;">skip: the purchase order is cancelled</xsl:when>
				<xsl:when test="normalize-space($h/*[local-name()=&apos;CardCode&apos;]) != normalize-space($h/*[local-name()=&apos;Vendor&apos;])">skip: the purchase order is not to Hi-Tech (VENDOR)</xsl:when>
				<xsl:when test="not($s)">Hi-Tech&apos;s query returned nothing</xsl:when>
				<xsl:when test="normalize-space($s/*[local-name()=&apos;Enabled&apos;]) != &apos;Y&apos;">skip: Hi-Tech&apos;s @MANNA_IC ENABLED is not Y</xsl:when>
				<xsl:when test="number($s/*[local-name()=&apos;SoCount&apos;]) &gt; 0">
					<xsl:value-of select="concat(&apos;skip: Hi-Tech order &apos;, normalize-space($s/*[local-name()=&apos;SoDocNum&apos;]), &apos; already carries this purchase order&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="number(concat(&apos;0&apos;, normalize-space($h/*[local-name()=&apos;HeaderDisc&apos;]))) != 0">the purchase order has a header discount - its line prices are not what Manna Treads pays</xsl:when>
				<xsl:when test="normalize-space($s/*[local-name()=&apos;CustomerType&apos;]) != &apos;C&apos;">
					<xsl:value-of select="concat(&apos;customer &apos;, normalize-space($s/*[local-name()=&apos;Customer&apos;]), &apos; (CUSTOMER) is missing or not a customer in Hi-Tech&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="normalize-space($s/*[local-name()=&apos;CustomerFrozen&apos;]) = &apos;Y&apos;">
					<xsl:value-of select="concat(&apos;customer &apos;, normalize-space($s/*[local-name()=&apos;Customer&apos;]), &apos; is inactive in Hi-Tech&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="string($tax) = &apos;&apos;">
					<xsl:value-of select="concat(&apos;no tax code for the customer state &quot;&apos;, $custState, &apos;&quot; (HOME_STATE / TAX_IN_STATE / TAX_OUT_STATE)&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="$badItem">
					<xsl:value-of select="concat(normalize-space($badItem/*[local-name()=&apos;ItemCode&apos;]), &apos; is not an active stock item Hi-Tech can sell&apos;)"></xsl:value-of>
				</xsl:when>
				<xsl:when test="$po[not(number(*[local-name()=&apos;Quantity&apos;]) &gt; 0) or not(number(*[local-name()=&apos;Price&apos;]) &gt; 0)]">a purchase order line has no quantity or price</xsl:when>
			</xsl:choose>
		</xsl:variable>

		<Decision>
			<PurchaseOrder><xsl:value-of select="normalize-space($h/*[local-name()=&apos;DocNum&apos;])"></xsl:value-of></PurchaseOrder>
			<!-- What the B1 Object atom (Hi-Tech's SysId) does, read by its Method,
			     Object, Key Name and Key Value fields as XPaths - no branch, which
			     this B1if never runs (see step 1's final.xsl). On N it only reads
			     Hi-Tech's customer record for Manna Treads (CUSTOMER, object 2),
			     there whenever Hi-Tech's settings are; nothing is written. -->
			<xsl:choose>
				<xsl:when test="string($why) != &apos;&apos;">
					<CallMethod>Synchronous Retrieval</CallMethod>
					<CallObject>2</CallObject>
					<CallKeyName>CardCode</CallKeyName>
					<CallKey><xsl:value-of select="normalize-space($s/*[local-name()=&apos;Customer&apos;])"></xsl:value-of></CallKey>
				</xsl:when>
				<xsl:otherwise>
					<CallMethod>Synchronous Insert</CallMethod>
					<CallObject>17</CallObject>
					<CallKeyName>DocEntry</CallKeyName>
					<CallKey></CallKey>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:choose>
				<xsl:when test="string($why) != &apos;&apos;">
					<Make>N</Make>
					<Reason><xsl:value-of select="$why"></xsl:value-of></Reason>
				</xsl:when>
				<xsl:otherwise>
					<Make>Y</Make>
					<Reason></Reason>
					<xsl:variable name="numAtCard" select="normalize-space($h/*[local-name()=&apos;NumAtCard&apos;])"></xsl:variable>
					<BOM>
						<BO>
							<AdmInfo><Object>17</Object><Version>2</Version></AdmInfo>
							<Documents>
								<row>
									<CardCode><xsl:value-of select="normalize-space($s/*[local-name()=&apos;Customer&apos;])"></xsl:value-of></CardCode>
									<DocDueDate><xsl:value-of select="translate(normalize-space($h/*[local-name()=&apos;DueDate&apos;]), &apos;-&apos;, &apos;&apos;)"></xsl:value-of></DocDueDate>
									<!-- The ERPNext name when the purchase order has one: the sync's
									     PASS H finds Hi-Tech's order by it, and PASS B follows it. -->
									<NumAtCard>
										<xsl:choose>
											<xsl:when test="$numAtCard != &apos;&apos;"><xsl:value-of select="$numAtCard"></xsl:value-of></xsl:when>
											<xsl:otherwise><xsl:value-of select="concat(&apos;MT PO &apos;, normalize-space($h/*[local-name()=&apos;DocNum&apos;]))"></xsl:value-of></xsl:otherwise>
										</xsl:choose>
									</NumAtCard>
									<Comments><xsl:value-of select="concat(&apos;Manna Treads PO &apos;, normalize-space($h/*[local-name()=&apos;DocNum&apos;]), &apos; - made by B1if&apos;)"></xsl:value-of></Comments>
									<DiscountPercent>0</DiscountPercent>
									<xsl:if test="normalize-space($s/*[local-name()=&apos;SoSeries&apos;]) != &apos;&apos;"><Series><xsl:value-of select="normalize-space($s/*[local-name()=&apos;SoSeries&apos;])"></xsl:value-of></Series></xsl:if>
									<xsl:if test="number($s/*[local-name()=&apos;SlpCode&apos;]) &gt; 0"><SalesPersonCode><xsl:value-of select="normalize-space($s/*[local-name()=&apos;SlpCode&apos;])"></xsl:value-of></SalesPersonCode></xsl:if>
									<U_MannaMtPo><xsl:value-of select="normalize-space($h/*[local-name()=&apos;DocEntry&apos;])"></xsl:value-of></U_MannaMtPo>
									<!-- The number people see on Manna Treads' sales order, so Hi-Tech's
									     orders can be searched by it. U_MannaMtPo is the machine's link. -->
									<U_MannaMtSoNo><xsl:value-of select="normalize-space($h/*[local-name()=&apos;MtSoNum&apos;])"></xsl:value-of></U_MannaMtSoNo>
								</row>
							</Documents>
							<Document_Lines>
								<xsl:for-each select="$po">
									<row>
										<ItemCode><xsl:value-of select="normalize-space(*[local-name()=&apos;ItemCode&apos;])"></xsl:value-of></ItemCode>
										<Quantity><xsl:value-of select="format-number(number(*[local-name()=&apos;Quantity&apos;]), &apos;0.######&apos;)"></xsl:value-of></Quantity>
										<Price><xsl:value-of select="format-number(number(*[local-name()=&apos;Price&apos;]), &apos;0.######&apos;)"></xsl:value-of></Price>
										<DiscountPercent>0</DiscountPercent>
										<TaxCode><xsl:value-of select="$tax"></xsl:value-of></TaxCode>
										<xsl:if test="normalize-space($s/*[local-name()=&apos;SoWhs&apos;]) != &apos;&apos;"><WarehouseCode><xsl:value-of select="normalize-space($s/*[local-name()=&apos;SoWhs&apos;])"></xsl:value-of></WarehouseCode></xsl:if>
									</row>
								</xsl:for-each>
							</Document_Lines>
						</BO>
					</BOM>
				</xsl:otherwise>
			</xsl:choose>
		</Decision>
	</xsl:template></xsl:stylesheet>