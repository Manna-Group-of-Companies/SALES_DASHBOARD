<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:param name="mtAtom" select="&apos;atom8&apos;"></xsl:param><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="quote">
		<xsl:param name="s"></xsl:param>
		<xsl:choose>
			<xsl:when test="contains($s, &quot;&apos;&quot;)">
				<xsl:value-of select="concat(substring-before($s, &quot;&apos;&quot;), &quot;&apos;&apos;&quot;)"></xsl:value-of>
				<xsl:call-template name="quote"><xsl:with-param name="s" select="substring-after($s, &quot;&apos;&quot;)"></xsl:with-param></xsl:call-template>
			</xsl:when>
			<xsl:otherwise><xsl:value-of select="$s"></xsl:value-of></xsl:otherwise>
		</xsl:choose>
	</xsl:template><xsl:template name="transform">
		<xsl:variable name="rows" select="/vpf:Msg/vpf:Body/vpf:Payload[@id=$mtAtom]//*[local-name()=&apos;Row&apos;]"></xsl:variable>
		<xsl:variable name="h" select="$rows[1]"></xsl:variable>
		<Sql>
			<Statement>
				<xsl:choose>
					<xsl:when test="not($h) or normalize-space($h/*[local-name()=&apos;DocEntry&apos;]) = &apos;&apos;">SELECT TOP 0 1 AS ItemCode</xsl:when>
					<xsl:otherwise>
SELECT
	X.ItemCode,
	ISNULL(I.SellItem, &apos;&apos;) AS SellItem, ISNULL(I.InvntItem, &apos;&apos;) AS InvntItem, ISNULL(I.frozenFor, &apos;&apos;) AS ItemFrozen,
	S.Enabled, S.Customer, S.SoSeries, S.SoWhs, S.HomeState, S.TaxInState, S.TaxOutState,
	ISNULL(C.CardType, &apos;&apos;) AS CustomerType, ISNULL(C.frozenFor, &apos;&apos;) AS CustomerFrozen, ISNULL(C.State1, &apos;&apos;) AS CustomerState,
	(SELECT COUNT(*) FROM ORDR O WHERE O.U_MannaMtPo = N&apos;<xsl:value-of select="normalize-space($h/*[local-name()=&apos;DocEntry&apos;])"></xsl:value-of>&apos; AND O.CANCELED = &apos;N&apos;) AS SoCount,
	(SELECT MIN(O.DocNum) FROM ORDR O WHERE O.U_MannaMtPo = N&apos;<xsl:value-of select="normalize-space($h/*[local-name()=&apos;DocEntry&apos;])"></xsl:value-of>&apos; AND O.CANCELED = &apos;N&apos;) AS SoDocNum,
	(SELECT MIN(SlpCode) FROM OSLP WHERE SlpName = N&apos;<xsl:call-template name="quote"><xsl:with-param name="s" select="normalize-space($h/*[local-name()=&apos;SlpName&apos;])"></xsl:with-param></xsl:call-template>&apos; AND SlpName &lt;&gt; &apos;&apos;) AS SlpCode
FROM (VALUES <xsl:for-each select="$rows"><xsl:if test="position() &gt; 1">, </xsl:if>(N&apos;<xsl:call-template name="quote"><xsl:with-param name="s" select="normalize-space(*[local-name()=&apos;ItemCode&apos;])"></xsl:with-param></xsl:call-template>&apos;)</xsl:for-each>) X(ItemCode)
CROSS JOIN (
	SELECT
		MAX(CASE WHEN Code = &apos;ENABLED&apos;       THEN U_Value END) AS Enabled,
		MAX(CASE WHEN Code = &apos;CUSTOMER&apos;      THEN U_Value END) AS Customer,
		MAX(CASE WHEN Code = &apos;SO_SERIES&apos;     THEN U_Value END) AS SoSeries,
		MAX(CASE WHEN Code = &apos;SO_WHS&apos;        THEN U_Value END) AS SoWhs,
		MAX(CASE WHEN Code = &apos;HOME_STATE&apos;    THEN U_Value END) AS HomeState,
		MAX(CASE WHEN Code = &apos;TAX_IN_STATE&apos;  THEN U_Value END) AS TaxInState,
		MAX(CASE WHEN Code = &apos;TAX_OUT_STATE&apos; THEN U_Value END) AS TaxOutState
	FROM [@MANNA_IC]
) S
LEFT JOIN OCRD C ON C.CardCode = S.Customer
LEFT JOIN OITM I ON I.ItemCode = X.ItemCode
</xsl:otherwise>
				</xsl:choose>
			</Statement>
		</Sql>
	</xsl:template></xsl:stylesheet>