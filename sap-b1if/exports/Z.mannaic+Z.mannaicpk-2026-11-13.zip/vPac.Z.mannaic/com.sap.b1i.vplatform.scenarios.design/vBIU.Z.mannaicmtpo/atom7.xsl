<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:param name="keyOf" select="&apos;so&apos;"></xsl:param><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="transform">
		<xsl:variable name="trigger" select="/vpf:Msg/vpf:Body/vpf:Payload[@Role=&apos;T&apos;]"></xsl:variable>
		<xsl:variable name="raw" select="string(($trigger//*[local-name()=&apos;key&apos;][*[local-name()=&apos;name&apos;]=&apos;DocEntry&apos;]/*[local-name()=&apos;value&apos;] | $trigger//*[local-name()=&apos;keys&apos;]//*[local-name()=&apos;value&apos;])[1])"></xsl:variable>
		<xsl:variable name="entry" select="number(normalize-space($raw))"></xsl:variable>
		<!-- In step 1 the purchase order was inserted moments ago by the same run,
		     and B1if commits a run's DI writes only when the run ends. This query
		     is on another connection, so a plain read waits for that commit,
		     which waits for this read: the run hung, and with it every read of
		     the company (5 Nov 2026, sales order 576). Reading without locks sees
		     the purchase order; if the run then fails, its Hi-Tech order is in the
		     same transaction and goes too. -->
		<xsl:variable name="nl"><xsl:if test="$keyOf = &apos;so&apos;"> WITH (NOLOCK)</xsl:if></xsl:variable>
		<Sql>
			<DocEntry><xsl:value-of select="$raw"></xsl:value-of></DocEntry>
			<Statement>
				<xsl:choose>
					<xsl:when test="string($entry) = &apos;NaN&apos; or $entry != floor($entry) or $entry &lt; 1">SELECT TOP 0 1 AS DocEntry</xsl:when>
					<xsl:otherwise>
SELECT
	P.DocEntry, P.DocNum, P.CANCELED AS Cancelled, P.CardCode, P.DiscPrcnt AS HeaderDisc,
	ISNULL(P.NumAtCard, &apos;&apos;) AS NumAtCard, ISNULL(P.U_MannaMtSo, &apos;&apos;) AS MtSo,
	CONVERT(char(10), CASE WHEN P.DocDueDate &lt; CAST(GETDATE() AS date) THEN CAST(GETDATE() AS date) ELSE P.DocDueDate END, 23) AS DueDate,
	L.LineNum, ISNULL(L.ItemCode, &apos;&apos;) AS ItemCode, L.Quantity, L.Price,
	ISNULL(SP.SlpName, &apos;&apos;) AS SlpName, ISNULL(CAST(SO.DocNum AS nvarchar(20)), &apos;&apos;) AS MtSoNum,
	(SELECT MAX(U_Value) FROM [@MANNA_IC]<xsl:value-of select="$nl"></xsl:value-of> WHERE Code = &apos;VENDOR&apos;) AS Vendor
FROM OPOR P<xsl:value-of select="$nl"></xsl:value-of>
JOIN POR1 L<xsl:value-of select="$nl"></xsl:value-of> ON L.DocEntry = P.DocEntry
LEFT JOIN ORDR SO<xsl:value-of select="$nl"></xsl:value-of> ON CAST(SO.DocEntry AS nvarchar(11)) = P.U_MannaMtSo
LEFT JOIN OSLP SP<xsl:value-of select="$nl"></xsl:value-of> ON SP.SlpCode = SO.SlpCode AND SO.SlpCode &gt; 0
<xsl:choose>
<xsl:when test="$keyOf = &apos;so&apos;">WHERE P.DocEntry = (SELECT MAX(Q.DocEntry) FROM OPOR Q<xsl:value-of select="$nl"></xsl:value-of> WHERE Q.U_MannaMtSo = N&apos;<xsl:value-of select="format-number($entry, &apos;0&apos;)"></xsl:value-of>&apos; AND Q.CANCELED = &apos;N&apos;)
</xsl:when>
<xsl:otherwise>WHERE P.DocEntry = <xsl:value-of select="format-number($entry, &apos;0&apos;)"></xsl:value-of>
</xsl:otherwise>
</xsl:choose>
ORDER BY L.LineNum
</xsl:otherwise>
				</xsl:choose>
			</Statement>
		</Sql>
	</xsl:template></xsl:stylesheet>