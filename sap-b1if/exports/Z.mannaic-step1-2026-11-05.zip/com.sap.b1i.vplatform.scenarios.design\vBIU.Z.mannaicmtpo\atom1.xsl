<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet xmlns:b1e="urn:com.sap.b1i.sim:b1event" xmlns:b1ie="urn:com.sap.b1i.sim:b1ievent" xmlns:b1im="urn:com.sap.b1i.sim:b1imessage" xmlns:bfa="urn:com.sap.b1i.bizprocessor:bizatoms" xmlns:jdbc="urn:com.sap.b1i.adapter:jdbcadapter" xmlns:js="com.sap.b1i.bpc_tools.Javascript" xmlns:rfc="urn:sap-com:document:sap:rfc:functions" xmlns:sim="urn:com.sap.b1i.sim:entity" xmlns:uplt="urn:com.sap.b1i.xcellerator:upltdoc" xmlns:utils2="com.sap.b1i.bpc_tools.Utilities" xmlns:vpf="urn:com.sap.b1i.vplatform:entity" xmlns:xci="urn:com.sap.b1i.xcellerator:intdoc" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" bfa:force="" vpf:force="" jdbc:force="" rfc:force="" b1ie:force="" b1e:force="" xci:force="" sim:force="" utils2:force="" b1im:force="" uplt:force="" js:force=""><xsl:output method="xml"></xsl:output><xsl:param name="atom"></xsl:param><xsl:param name="sessionid"></xsl:param><xsl:variable name="msg" select="/vpf:Msg/vpf:Body/vpf:Payload[./@Role=&apos;S&apos;]"></xsl:variable><xsl:variable name="vpSender" select="/vpf:Msg/vpf:Header/vpf:Sender/@Id"></xsl:variable><xsl:variable name="vpObject" select="/vpf:Msg/vpf:Header/vpf:Sender/@ObjId"></xsl:variable><xsl:variable name="vpReceiver" select="/vpf:Msg/vpf:Header/vpf:ReceiverList/vpf:Receiver[./@handover=&apos;P&apos;]/@Id"></xsl:variable><xsl:template match="/"><xsl:variable name="vptsDoc" select="document(&apos;/com.sap.b1i.internal/xml/timestamp&apos;)"></xsl:variable><xsl:variable name="vpts" select="concat($vptsDoc/*/@year,&apos;/&apos;,$vptsDoc/*/@month,&apos;/&apos;,$vptsDoc/*/@date,&apos; &apos;,$vptsDoc/*/@hour,&apos;:&apos;,$vptsDoc/*/@minute,&apos;:&apos;,$vptsDoc/*/@second)"></xsl:variable><vpf:Msg>
			<xsl:copy-of select="/vpf:Msg/@*"></xsl:copy-of>
			<xsl:copy-of select="/vpf:Msg/vpf:Header"></xsl:copy-of>
			<vpf:Body>
				<xsl:copy-of select="/vpf:Msg/vpf:Body/*"></xsl:copy-of>
				<vpf:Payload Role="X" id="{$atom}">
					<xsl:call-template name="transform"></xsl:call-template>
				</vpf:Payload>
			</vpf:Body>
		</vpf:Msg></xsl:template><xsl:template name="transform">
		<!-- The B1 event's key, matched by local name so the event's namespace
		     prefix cannot break it. -->
		<xsl:variable name="trigger" select="/vpf:Msg/vpf:Body/vpf:Payload[@Role=&apos;T&apos;]"></xsl:variable>
		<xsl:variable name="raw" select="string(($trigger//*[local-name()=&apos;key&apos;][*[local-name()=&apos;name&apos;]=&apos;DocEntry&apos;]/*[local-name()=&apos;value&apos;] | $trigger//*[local-name()=&apos;keys&apos;]//*[local-name()=&apos;value&apos;])[1])"></xsl:variable>
		<xsl:variable name="entry" select="number(normalize-space($raw))"></xsl:variable>
		<Sql>
			<DocEntry><xsl:value-of select="$raw"></xsl:value-of></DocEntry>
			<Statement>
				<xsl:choose>
					<!-- Not a whole number: a query that returns nothing, so the
					     final atom says so and makes nothing. -->
					<xsl:when test="string($entry) = &apos;NaN&apos; or $entry != floor($entry) or $entry &lt; 1">SELECT TOP 0 1 AS DocEntry</xsl:when>
					<xsl:otherwise>
SELECT
	T0.DocEntry, T0.DocNum, T0.CANCELED AS Cancelled, T0.DocStatus, T0.DiscPrcnt AS HeaderDisc,
	CONVERT(char(10), T0.DocDate, 23) AS DocDate,
	CONVERT(char(10), CASE WHEN T0.DocDueDate &lt; CAST(GETDATE() AS date) THEN CAST(GETDATE() AS date) ELSE T0.DocDueDate END, 23) AS DueDate,
	ISNULL(T0.NumAtCard, &apos;&apos;) AS NumAtCard, LEFT(ISNULL(CAST(T0.Comments AS nvarchar(254)), &apos;&apos;), 254) AS Remarks,
	T1.LineNum, ISNULL(T1.ItemCode, &apos;&apos;) AS ItemCode, T1.Quantity, T1.PriceAfVAT, T1.VatPrcnt, T1.DiscPrcnt AS LineDisc,
	ISNULL(I.InvntItem, &apos;&apos;) AS InvntItem, ISNULL(I.PrchseItem, &apos;&apos;) AS PrchseItem, ISNULL(I.frozenFor, &apos;&apos;) AS ItemFrozen,
	S.Enabled, S.StartDate, S.Margin, S.Vendor, S.PoSeries, S.PoBranch, S.PoWhs, S.PoLocation,
	S.HomeState, S.TaxInState, S.TaxOutState, S.ErpPrefix,
	ISNULL(V.CardType, &apos;&apos;) AS VendorType, ISNULL(V.frozenFor, &apos;&apos;) AS VendorFrozen, ISNULL(V.State1, &apos;&apos;) AS VendorState,
	(SELECT COUNT(*) FROM OPOR P WHERE P.U_MannaMtSo = CAST(T0.DocEntry AS nvarchar(11)) AND P.CANCELED = &apos;N&apos;) AS PoCount,
	(SELECT MIN(P.DocNum) FROM OPOR P WHERE P.U_MannaMtSo = CAST(T0.DocEntry AS nvarchar(11)) AND P.CANCELED = &apos;N&apos;) AS PoDocNum
FROM ORDR T0
JOIN RDR1 T1 ON T1.DocEntry = T0.DocEntry
LEFT JOIN OITM I ON I.ItemCode = T1.ItemCode
CROSS JOIN (
	SELECT
		MAX(CASE WHEN Code = &apos;ENABLED&apos;       THEN U_Value END) AS Enabled,
		MAX(CASE WHEN Code = &apos;START_DATE&apos;    THEN U_Value END) AS StartDate,
		MAX(CASE WHEN Code = &apos;MARGIN&apos;        THEN U_Value END) AS Margin,
		MAX(CASE WHEN Code = &apos;VENDOR&apos;        THEN U_Value END) AS Vendor,
		MAX(CASE WHEN Code = &apos;PO_SERIES&apos;     THEN U_Value END) AS PoSeries,
		MAX(CASE WHEN Code = &apos;PO_BRANCH&apos;     THEN U_Value END) AS PoBranch,
		MAX(CASE WHEN Code = &apos;PO_WHS&apos;        THEN U_Value END) AS PoWhs,
		MAX(CASE WHEN Code = &apos;PO_LOCATION&apos;   THEN U_Value END) AS PoLocation,
		MAX(CASE WHEN Code = &apos;HOME_STATE&apos;    THEN U_Value END) AS HomeState,
		MAX(CASE WHEN Code = &apos;TAX_IN_STATE&apos;  THEN U_Value END) AS TaxInState,
		MAX(CASE WHEN Code = &apos;TAX_OUT_STATE&apos; THEN U_Value END) AS TaxOutState,
		MAX(CASE WHEN Code = &apos;ERP_PREFIX&apos;    THEN U_Value END) AS ErpPrefix
	FROM [@MANNA_IC]
) S
LEFT JOIN OCRD V ON V.CardCode = S.Vendor
WHERE T0.DocEntry = <xsl:value-of select="format-number($entry, &apos;0&apos;)"></xsl:value-of>
ORDER BY T1.LineNum
</xsl:otherwise>
				</xsl:choose>
			</Statement>
		</Sql>
	</xsl:template></xsl:stylesheet>